/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_concat_params.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/01 08:49:49 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/01 22:42:07 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int		ft_memsize(int argc, char **argv)
{
	int i;
	int j;
	int memsize;

	i = 0;
	memsize = 0;
	while (++i < argc)
	{
		j = -1;
		while (++j <= ft_strlen(argv[i]) + 1)
			memsize++;
	}
	return (memsize);
}

char	*ft_concat_params(int argc, char **argv)
{
	int		memsize;
	char	*res;
	int		res_ix;
	int		i;
	int		j;

	memsize = ft_memsize(argc, argv);
	res = (char *)malloc(sizeof(*res) * memsize);
	i = 0;
	res_ix = 0;
	while (++i < argc)
	{
		j = -1;
		while (++j < ft_strlen(argv[i]))
		{
			res[res_ix] = argv[i][j];
			res_ix++;
		}
		if (i != (argc - 1))
			res[res_ix] = '\n';
		else
			res[res_ix] = '\0';
		res_ix++;
	}
	return (res);
}
