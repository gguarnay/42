/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/31 16:04:28 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/31 18:00:23 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int *tab;
	int i;

	tab = (int *)malloc(sizeof(int) * (max - min + 1));
	i = -1;
	while (++i < max - min)
		tab[i] = i + min;
	return (tab);
}
