#!/bin/sh

ldapsearch -Q "(uid=z*)" | grep "^cn: " | sort -r --ignore-case | sed "s/^cn: //"
