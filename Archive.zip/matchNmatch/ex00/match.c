/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   match.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 00:15:14 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/04 01:56:47 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	test_empty_string(char *s1, char *s2)
{
	if ((*s1 == '\0' && *s2 != '\0')
			|| (*s1 != '\0' && *s2 == '\0'))
		return (0);
	return (1);
}

int	match(char *s1, char *s2)
{
	int i;
	int j;

	i = -1;
	j = 0;
	while (s2[++i])
	{
		if (s2[i] != '*')
			if (s1[j] != s2[i])
				return (0);
		if (s2[i] == '*')
		{
			while ((s2[i] == '*') && (s2[i + 1] != '\0'))
				i++;
			if (s2[i + 1] == '\0')
				return (1);
			j--;
			while (s1[++j] != s2[i])
				if (s1[j] == '\0')
					return (0);
		}
		j++;
	}
	if ((i > 1 && s2[i - 2] == '*' && s2[i-1] != '*')
			&& (s2[i-1] == s1[ft_strlen(s1) - 1]))
		return (1);
	return (test_empty_string(s1, s2));
}
