/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/01 23:41:23 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/02 01:32:04 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int		ft_is_pm_beg(int hour)
{
	if (hour >= 1200 && hour <= 2359)
		return (1);
	else
		return (0);
}

int		ft_is_pm_end(int hour)
{
	if (hour >= 1100 && hour <= 2259)
		return (1);
	else
		return (0);
}

int		ft_time_beg(int hour)
{
	if (hour >= 1300 && hour <= 2359)
		return (hour / 100 - 12);
	if (hour >= 1200 && hour <= 1259)
		return (12);
	if (hour >= 0 && hour <= 1159)
		return (hour / 100);
	return (0);
}

int		ft_time_end(int hour)
{
	if (hour >= 0 && hour <= 1059)
		return (hour / 100 + 1);
	if (hour >= 1200 && hour <= 2259)
		return (hour / 100 - 12) + 1;
	if ((hour >= 2300 && hour <= 2359)
			|| (hour >= 1100 && hour <= 1159))
		return (12);
	return (0);
}

void	ft_takes_place(int hour)
{
	int		th_time_beg;
	int		th_time_end;
	char	*th_am_pm_beg;
	char	*th_am_pm_end;

	th_am_pm_beg = ft_is_pm_beg(hour) ? "P.M." : "A.M.";
	th_am_pm_end = ft_is_pm_end(hour) ? "P.M." : "A.M.";
	th_time_beg = ft_time_beg(hour);
	th_time_end = ft_time_end(hour);
	printf("THE FOLLOWING TAKES PLACE BETWEEN %d.00 %s AND %d.00 %s\n",
			th_time_beg, th_am_pm_beg, th_time_end, th_am_pm_end);
}
