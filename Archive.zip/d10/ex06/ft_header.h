/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_header.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/05 18:32:31 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/06 21:17:43 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_HEADER_H
# define FT_HEADER_H
# include <unistd.h>

typedef int		(*t_func)(int, int);

int				ft_add(int a, int b);
int				ft_sub(int a, int b);
int				ft_mod(int a, int b);
int				ft_mul(int a, int b);
int				ft_div(int a, int b);
void			ft_putstr(char *s);
void			ft_putchar(char c);
int				is_whitesp(char *str, int i);
int				is_digit(char *str, int i);
int				ft_atoi(char *str);
int				ft_calculate(int a, int b, char *op);
int				ft_apply_function(int a, int b, int (*f)(int, int));
int				ft_is_valid_operator(char *s);
int				ft_strcmp(char *s1, char *s2);
void			ft_putnbr(int n);

#endif
