/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_doop.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/05 18:26:33 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/06 21:28:41 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

int	ft_is_valid_operator(char *s)
{
	if (*s == '+' || *s == '-' ||
			*s == '/' || *s == '%' ||
			*s == '*')
		return (1);
	return (0);
}

int	ft_apply_function(int a, int b, int (*f)(int, int))
{
	return (f(a, b));
}

int	ft_calculate(int a, int b, char *op)
{
	t_func	functions[5];

	functions[0] = &ft_add;
	functions[1] = &ft_sub;
	functions[2] = &ft_mul;
	functions[3] = &ft_div;
	functions[4] = &ft_mod;
	if (ft_strcmp(op, "+") == 0)
		return (ft_apply_function(a, b, functions[0]));
	if (ft_strcmp(op, "-") == 0)
		return (ft_apply_function(a, b, functions[1]));
	if (ft_strcmp(op, "*") == 0)
		return (ft_apply_function(a, b, functions[2]));
	if (ft_strcmp(op, "/") == 0)
		return (ft_apply_function(a, b, functions[3]));
	if (ft_strcmp(op, "%") == 0)
		return (ft_apply_function(a, b, functions[4]));
	return (0);
}

int	main(int argc, char **argv)
{
	int	a;
	int b;
	int res;

	if (argc != 4)
		return (0);
	if (ft_is_valid_operator(argv[2]) == 0)
	{
		ft_putchar('0');
		ft_putchar('\n');
		return (0);
	}
	a = ft_atoi(argv[1]);
	b = ft_atoi(argv[3]);
	res = ft_calculate(a, b, argv[2]);
	if ((*argv[2] == '/' && b == 0) || (*argv[2] == '%' && b == 0))
	{
		ft_putchar('\n');
		return (0);
	}
	ft_putnbr(res);
	ft_putchar('\n');
	return (0);
}
