/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_doop.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/05 18:26:33 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/06 20:43:42 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"
#include "ft_opp.h"

t_myfunc	ft_operator(char *s)
{
	int i;

	i = 0;
	while (ft_strcmp(g_opptab[i].op, "") != 0)
	{
		if (ft_strcmp(s, g_opptab[i].op) == 0)
			return (g_opptab[i].f);
		i++;
	}
	return (g_opptab[i].f);
}

int			ft_apply_function(int a, int b, int (*f)(int, int))
{
	return (f(a, b));
}

int			ft_usage(int a, int b)
{
	int i;

	i = 0;
	ft_putstr("error : only [ ");
	while (ft_strcmp(g_opptab[i].op, "") != 0)
	{
		ft_putstr(g_opptab[i].op);
		ft_putchar(' ');
		i++;
	}
	ft_putstr("] are accepted.");
	i = a;
	i = b;
	return (0);
}

int			main(int argc, char **argv)
{
	int			a;
	int			b;
	int			res;
	t_myfunc	f;

	if (argc != 4)
		return (0);
	f = ft_operator(argv[2]);
	a = ft_atoi(argv[1]);
	b = ft_atoi(argv[3]);
	if (f == ft_usage)
	{
		ft_usage(a, b);
		ft_putchar('\n');
		return (0);
	}
	res = ft_apply_function(a, b, f);
	if ((*argv[2] == '/' && b == 0) || (*argv[2] == '%' && b == 0))
	{
		ft_putchar('\n');
		return (0);
	}
	ft_putnbr(res);
	ft_putchar('\n');
	return (0);
}
