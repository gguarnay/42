/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_level_count.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/09 15:01:54 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/09 16:05:42 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

int	btree_level_count(t_btree *root)
{
	t_btree *current;
	t_btree *prev;
	int		count;

	current = root;
	if (!root)
		return (0);
	while (current)
	{
		if (current->left)
		{
			current = current->left;
		}
		if (cmpf(current->item, data_ref) == 0)
			return (current);
		if (current->right)
		{
			prev = current;
			current = current->right;
		}
	}
	return (1);
}
