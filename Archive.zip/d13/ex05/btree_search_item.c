/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_search_item.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/09 14:42:15 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/09 16:03:21 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"
#include <stdlib.h>

void	*btree_search_item(t_btree *root, void *data_ref,
		int (*cmpf)(void *, void *))
{
	t_btree *current;

	current = root;
	if (!root)
		return ;
	if (current->left)
		btree_search_item(current->left, data_ref, cmpf);
	if (cmpf(current->item, data_ref) == 0)
		return (current->item);
	if (current->right)
		btree_search_item(current->right, data_ref, cmpf);
	return (NULL);
}
