/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_apply_prefix.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/09 11:24:19 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/09 12:42:10 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void	btree_apply_prefix(t_btree *root, void (*applyf)(void *))
{
	t_btree *current;

	current = root;
	if (!root)
		return ;
	applyf(current->item);
	if (current->left)
		btree_apply_prefix(current->left, applyf);
	if (current->right)
		btree_apply_prefix(current->right, applyf);
}
