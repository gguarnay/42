/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_insert_data.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/09 13:16:06 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/09 13:41:37 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void	btree_insert_data(t_btree **root, void *item, void (*applyf)(void *))
{
	t_btree *current;

	current = *root;
	if (!(*root))
		*root = btree_create_node(item);
	while (current)
	{
		if (strcmp(item, current) < 0)
			if (current->left == 0)
			{
				current->left = btree_create_node(item);
				break ;
			}
			else
				current = current->left;
		if (strcmp(item, current) >= 0)
			if (current->right == 0)
			{
				current->right = btree_create_node(item);
				break ;
			}
			else
				current = current->right;
	}
}
