/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_apply_infix.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/09 12:43:17 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/09 13:18:14 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void	btree_apply_infix(t_btree *root, void (*applyf)(void *))
{
	t_btree *current;

	current = root;
	if (!root)
		return ;
	if (current->left)
		btree_apply_prefix(current->left, applyf);
	applyf(current->item);
	if (current->right)
		btree_apply_prefix(current->right, applyf);
}
