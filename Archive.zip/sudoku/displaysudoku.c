/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   displaysudoku.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 12:44:15 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/04 13:53:29 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_displaysudoku(int **array)
{
	int row;
	int col;

	row = -1;
	col = -1;
	while (++row < 9)
	{
		while (++col < 9)
		{
			ft_putchar(array[row][col] + '0');
			if (col < 8)
				ft_putchar(' ');
		}
		col = -1;
		ft_putchar('\n');
	}
}
