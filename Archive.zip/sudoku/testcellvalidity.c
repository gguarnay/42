/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   testcellvalidity.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 20:29:55 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/04 21:22:13 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

int	ft_testrow(int **array, int row, int col, int value)
{
	int j;

	j = 0;
	while (j < 9)
	{
		if (array[row][j] == value && j != col)
			return (0);
		j++;
	}
	return (1);
}

int	ft_testcol(int **array, int row, int col, int value)
{
	int i;

	i = 0;
	while (i < 9)
	{
		if (array[i][col] == value && i != row)
			return (0);
		i++;
	}
	return (1);
}

int	ft_testsquare(int **array, int row, int col, int value)
{
	return (1);	
}
