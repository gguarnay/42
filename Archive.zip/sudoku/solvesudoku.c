/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solvesudoku.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 14:15:52 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/04 20:50:19 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//// test that the position is safe
//		1) same digit not on the same row
//		2) same digit not on the same col
//		3) same digit not in the same 9-squares
		// track 9-square I belong to
		// identify other values in the 9-square
			// ==> need 9-square array in integer (int *square[9])

// recursion -- we need to create the canvas for the recursion
//		1) define struct positions
//			a) col
//			b) row
//			c) actual value (1-9)

#include <stdlib.h>
#include "ft_header.h"

int		ft_avail_pos_count(int **array)
{
	int i;
	int j;
	int count_zeros;

	i = -1;
	j = -1;
	count_zeros = 0;
	while (++i < 9)
	{
		while (++j < 9)
		{
			if (array[i][j] == 0)
				count_zeros++;
		}
		j = -1;
	}
	return (count_zeros);
}

void	ft_fill_up_array(int **array, t_pos *positions, int pos)
{
	int i;

	i = 0;
	while (i < pos)
	{
		arr[positions[i].row][positions[i].col] = positions[i].value;
		i++;
	}
}

int		ft_is_available_cell(int row, int col, t_pos *fpositions, int fpos)
{
	int i;
	int found_forbidden;

	i = 0;
	found_forbidden = 0;
	while (i < fpos)
	{
		if (row == fpositions[i].row && col == fpositions[i].col)
			found_forbidden = 1;
	}
	if (found_forbidden == 0)
		return (1);
	return (0);
}

void	ft_solvesudoku(int **array, t_pos *fpositions)
{
	t_pos	*positions;
	int		avail_pos;
	int		has_positions;

	avail_pos = ft_avail_pos_count(array);
	positions = (t_pos *)malloc(sizeof(t_pos) * ft_avail_pos_count(array));
	has_positions = ft_solvesudoku_util(avail_pos, 0, 0, positions, fpositions);
	if (has_positions)
		ft_fill_up_array(array, positions, avail_pos);
	ft_displaysudoku(array);
	free(positions); // check behavior of free
	free(array); // check behavior of free;
}

int		ft_solvesudoku_util(int avail_pos, int row, int col, t_pos *positions, t_pos *fpositions)
{
	int value;

	value = 0;
	if (row == 9 && col == 9)
		return (1);
	while (row < 10)
		while (col < 10)
			//cell = 0;// tracks available position
			if (ft_is_available_cell(row, col, fpositions, 81 - avail_pos) == 1) // [OK] if you are not forbidden position you play 
				value = 1;
				positionSafe = 1;
				cell = 0; // CANT USE exterior variable cell; nedds to use row and col too (as used in the recursion);
				while (++value < 10)
					// check it's a invalid value for the given row and col
					arra
					positionSafe = 0;
					break;

				if (positionSafe)
					positions[cell].row = row;
					positions[cell].col = col;
					positions[cell].value = value;
					if (col < 8)
						return (ft_solvesudoku_util(avail_pos, row, col + 1, positions, fpositions));
					else
						return (ft_solvesudoku_util(avail_pos, row + 1 , 0, positions, fpositions);
	return (0);
}
