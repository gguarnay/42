/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_header.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 16:40:41 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/04 20:51:08 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_HEADER_H
# define FT_HEADER_H

typedef struct	s_position
{
	int row;
	int col;
	int value;
}				t_pos;

void			ft_displaysudoku(int **array);
void			ft_putchar(char c);
void			ft_solvesudoku(int **array, t_pos *fpositions);
int				ft_testrow(int **array, int row, int col, int value);
int				ft_testcol(int **array, int row, int col, int value);
int				ft_testsquare(int **array, int row, int col, int value);

#endif
