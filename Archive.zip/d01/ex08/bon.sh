#!/bin/sh
ldapsearch -Q "(sn=*bon*)" | grep '# numEntries: ' | sed 's/\# numEntries: //'
