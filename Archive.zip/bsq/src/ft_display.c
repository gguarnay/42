/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/12 23:58:57 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/13 14:30:56 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *s)
{
	while (*s)
	{
		ft_putchar(*s);
		s++;
	}
}

void	ft_display(char **result, t_square_br res, int *map_size, char c)
{
	int i;
	int j;

	i = -1;
	j = 0;
	while (++i < map_size[0])
	{
		while (j < map_size[1])
		{
			if ((i <= res.row && i >= res.row - res.size + 1) &&
					(j <= res.col && j >= res.col - res.size + 1))
				ft_putchar(c);
			else
				ft_putchar(result[i][j]);
			j++;
		}
		ft_putchar('\n');
		j = 0;
	}
}
