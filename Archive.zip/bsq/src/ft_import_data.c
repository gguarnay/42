/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_import_data.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/14 20:35:28 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/14 20:35:42 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"
#define BUF_SIZE 65000

void		ft_fill_allowed_chars(char *buf, t_filedesc *f_desc)
{
	int		i;

	i = 0;
	while (buf[i] >= '0' && buf[i] <= '9')
		i++;
	f_desc->c[0] = buf[i++];
	f_desc->c[1] = buf[i++];
	f_desc->c[2] = buf[i];
}

void		ft_extract_file_desc(t_filedesc *f_desc, int fd, int buf_size)
{
	int			ret;
	char		*buf;
	int			i;

	f_desc->b_size = buf_size;
	f_desc->is_valid = buf_size == -1 ? -1 : 1;
	buf = (char *)malloc(buf_size + 1);
	if (buf == NULL)
		f_desc->is_valid = -1;
	i = 0;
	while ((ret = read(fd, buf, buf_size)))
	{
		buf[ret] = '\0';
		f_desc->map_size[0] = ft_atoi(buf);
		ft_fill_allowed_chars(buf, f_desc);
		while (buf[i] >= '0' && buf[i] <= '9')
			i++;
		i = i + 4;
		f_desc->si = i;
		f_desc->map_size[1] = 0;
		while (buf[f_desc->map_size[1] + i] != '\n')
			f_desc->map_size[1]++;
		break ;
	}
	free(buf);
}

void		ft_import_data(int *fdret, t_filedesc *f_d, char *buf, t_tabs *t)
{
	int x[2];
	int i;

	i = f_d->si;
	ft_init_x_tabs(x);
	while (fdret[1])
	{
		while (buf[i])
		{
			if (buf[i] == '\n')
			{
				(t->re)[x[0]++][x[1]] = '\0';
				if (buf[++i] == '\0')
					break ;
				x[1] = 0;
				(t->ca)[x[0]] = malloc(sizeof(int) * (f_d->map_size[1]));
				(t->re)[x[0]] = malloc(sizeof(char) * (f_d->map_size[1] + 1));
			}
			(t->ca)[x[0]][x[1]] = buf[i] == f_d->c[0] ? 1 : 0;
			(t->re)[x[0]][x[1]++] = buf[i++];
		}
		i = 0;
		fdret[1] = read(fdret[0], buf, f_d->b_size);
		buf[fdret[1]] = '\0';
	}
}

void		ft_import_data_stdin(int r, t_filedesc *f_d, char *buf, t_tabs *t)
{
	int x[2];
	int i;

	ft_init_x_tabs(x);
	r = read(0, buf, f_d->b_size);
	i = f_d->si;
	while (buf[i])
	{
		if (buf[i] == '\n')
		{
			(t->re)[x[0]++][x[1]] = '\0';
			if (buf[++i] == '\0')
				break ;
			x[1] = 0;
			(t->ca)[x[0]] = malloc(sizeof(int) * (f_d->map_size[1]));
			(t->re)[x[0]] = malloc(sizeof(char) * (f_d->map_size[1] + 1));
		}
		(t->ca)[x[0]][x[1]] = buf[i] == f_d->c[0] ? 1 : 0;
		(t->re)[x[0]][x[1]++] = buf[i++];
	}
	i = 0;
}

int			ft_check_map_validity(char *filename)
{
	int		fd;
	int		ret;
	char	*buf;
	int		buf_size;

	fd = open(filename, O_RDONLY);
	if (fd > 0)
	{
		buf_size = ft_ideal_buffer_size(filename);
		buf = malloc(sizeof(char) * (buf_size + 1));
		if ((ret = read(fd, buf, buf_size)) < 0)
		{
			free(buf);
			return (1);
		}
		if (ft_test_first_char(buf) != 0 || ft_test_allowed_chars(buf) != 0 ||
			ft_test_cols(buf) != 0 || ft_test_rows(buf) != 0)
		{
			free(buf);
			write(2, "map error\n", 10);
			close(fd);
			return (20);
		}
	}
	close(fd);
	return (0);
}
