/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/12 14:00:09 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/13 14:35:53 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"
#include <stdio.h>

t_filedesc	ft_file_preprocessing(char *filename)
{
	t_filedesc	*f_desc;
	int			fd_bis;
	int			buf_size;

	f_desc = (t_filedesc *)malloc(sizeof(t_filedesc));
	fd_bis = open(filename, O_RDONLY);
	buf_size = ft_ideal_buffer_size(filename);
	ft_extract_file_desc(f_desc, fd_bis, buf_size);
	if (ft_closefile_error(fd_bis) > 0)
	{
		f_desc->is_valid = 0;
	}
	return (*f_desc);
}

t_filedesc	ft_stdin_preprocessing(void)
{
	t_filedesc	*f_desc;
	int			b_size;

	f_desc = (t_filedesc *)malloc(sizeof(t_filedesc));
	b_size = ft_ideal_buffer_size_stdin();
	ft_extract_file_desc(f_desc, 0, b_size);
	return (*f_desc);
}

int			ft_ctrl_preprocessing(char *filename, t_filedesc *f_desc, int *fd)
{
	int		map_error;

	map_error = 0;
	if (filename)
	{
		map_error = ft_check_map_validity(filename);
		if (map_error != 0)
			return (9);
		*f_desc = ft_file_preprocessing(filename);
		*fd = open(filename, O_RDONLY);
		if (ft_openfile_error(*fd) > 0)
			return (0);
	}
	else
	{
		*f_desc = ft_stdin_preprocessing();
		*fd = 0;
	}
	return (0);
}

int			ft_controller(char *filename)
{
	int			fdret[2];
	char		*buf;
	t_tabs		*tabs;
	t_square_br res;
	t_filedesc	f_desc;

	fdret[0] = 0;
	if (ft_ctrl_preprocessing(filename, &f_desc, &fdret[0]) != 0)
		return (20);
	buf = (char *)malloc(f_desc.b_size + 1);
	fdret[1] = ft_init_buf_ret(buf, fdret[0], f_desc.b_size);
	tabs = ft_init_tabs(f_desc);
	if (filename)
	{
		ft_import_data(fdret, &f_desc, buf, tabs);
		if (ft_closefile_error(fdret[0]) > 0)
			return (4000);
	}
	else
		ft_import_data_stdin(fdret[1], &f_desc, buf, tabs);
	res = ft_solve_bsq(tabs->ca, f_desc.map_size);
	ft_display(tabs->re, res, f_desc.map_size, f_desc.c[2]);
	free(buf);
	free(tabs);
	return (0);
}

int			main(int argc, char **argv)
{
	int i;
	int ret_value;

	ret_value = 0;
	if (argc <= 1)
	{
		ft_controller(0);
		return (0);
	}
	else
	{
		i = 0;
		while (++i < argc)
			ret_value += ft_controller(argv[i]);
	}
	return (ret_value);
}
