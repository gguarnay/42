/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/10 15:38:41 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/10 15:40:05 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

int		is_whitesp(char *str, int i)
{
	if ((str[i] == ' ') || (str[i] == '\t') || (str[i] == '\r') ||
		(str[i] == '\n') || (str[i] == '\v') || (str[i] == '\f'))
		return (1);
	return (0);
}

int		is_digit(char *str, int i)
{
	if (str[i] >= '0' && str[i] <= '9')
		return (1);
	return (0);
}

int		ft_atoi(char *str)
{
	int i;
	int temp;
	int res;

	i = 0;
	temp = 1;
	res = 0;
	while (is_whitesp(str, i) == 1)
		i++;
	str += i;
	i = 0;
	if (str[0] == '+' || str[0] == '-')
	{
		temp = str[0] == '-' ? -1 : 1;
		str += 1;
	}
	while (str[i] != '\0' && is_whitesp(str, i) == 0 && is_digit(str, i) == 1)
		i++;
	while (--i >= 0)
	{
		res += temp * (str[i] - '0');
		temp *= 10;
	}
	return (res);
}
