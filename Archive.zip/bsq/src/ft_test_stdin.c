/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_test_stdin.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/14 22:48:30 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/14 22:48:33 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

int			ft_check_map_validity_stdin(void)
{
	int		ret;
	char	*buf;
	int		buf_size;

	buf_size = ft_ideal_buffer_size_stdin();
	buf = malloc(sizeof(char) * (buf_size + 1));
	if ((ret = read(0, buf, buf_size)) < 0)
	{
		free(buf);
		return (1);
	}
	if (ft_test_first_char(buf) != 0 || ft_test_allowed_chars(buf) != 0 ||
		ft_test_cols(buf) != 0 || ft_test_rows(buf) != 0)
	{
		free(buf);
		write(2, "map error", 9);
		return (20);
	}
	return (0);
}
