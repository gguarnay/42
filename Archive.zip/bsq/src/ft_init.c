/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/14 20:30:32 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/14 20:30:46 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

int			ft_openfile_error(int fd)
{
	if (fd == -1)
	{
		ft_putstr("Error on file open().\n");
		return (20);
	}
	return (0);
}

int			ft_closefile_error(int fd)
{
	if (close(fd) == -1)
	{
		ft_putstr("Error on file close().\n");
		return (4000);
	}
	return (0);
}

void		ft_init_x_tabs(int *ix)
{
	ix[0] = 0;
	ix[1] = 0;
}

t_tabs		*ft_init_tabs(t_filedesc f_desc)
{
	t_tabs	*tmp_tabs;

	tmp_tabs = malloc(sizeof(t_tabs));
	tmp_tabs->ca = (int **)malloc(sizeof(int *) * (f_desc.map_size[0]));
	tmp_tabs->re = (char **)malloc(sizeof(char *) * (f_desc.map_size[0]));
	tmp_tabs->ca[0] = (int *)malloc(sizeof(int) * (f_desc.map_size[1]));
	tmp_tabs->re[0] = (char *)malloc(sizeof(char) * (f_desc.map_size[1] + 1));
	return (tmp_tabs);
}

int			ft_init_buf_ret(char *buf, int fd, int b_size)
{
	int ret;

	while ((ret = read(fd, buf, b_size)))
	{
		buf[ret] = '\0';
		break ;
	}
	return (ret);
}
