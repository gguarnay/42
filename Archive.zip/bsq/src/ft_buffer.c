/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_buffer.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/14 20:36:15 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/14 20:36:37 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"
#define BUF_SIZE 65000

int			ft_ideal_buffer_size(char *filename)
{
	int		i;
	int		fdret[2];
	char	*buf;
	int		buf_size;

	buf_size = BUF_SIZE;
	buf = (char *)malloc(buf_size + 1);
	if (buf == NULL || (fdret[0] = open(filename, O_RDONLY)) < 0)
		return (-1);
	while ((fdret[1] = read(fdret[0], buf, buf_size)) && buf[i] != '\n')
	{
		if (fdret[1] == buf_size)
		{
			buf_size *= 2;
			free(buf);
			buf = (char *)malloc(buf_size + 1);
		}
		buf[fdret[1]] = '\0';
		i = 0;
		while (buf[i] != '\n' && buf[i] != '\0')
			i++;
	}
	free(buf);
	return ((ft_closefile_error(fdret[0]) > 0) ? -1 : buf_size);
}

int			ft_ideal_buffer_size_stdin(void)
{
	return (BUF_SIZE);
}
