/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_solve_bsq.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/12 21:42:59 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/12 21:43:19 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

void			ft_init_ix(int *ix)
{
	ix[0] = -1;
	ix[1] = -1;
}

t_square_br		ft_init_size_to_one(int *ix)
{
	t_square_br	this_sq;

	this_sq.size = 1;
	this_sq.row = ix[0];
	this_sq.col = ix[1];
	return (this_sq);
}

t_square_br		ft_find_largest_square(int **ca, int *ix)
{
	t_square_br this_sq;

	this_sq.size = ca[ix[0]][ix[1]];
	this_sq.row = ix[0];
	this_sq.col = ix[1];
	return (this_sq);
}

t_square_br		ft_solve_bsq(int **ca, int *map_size)
{
	t_square_br	sq;
	int			x[2];

	ft_init_ix(x);
	sq.size = 0;
	while (++x[0] < map_size[0])
	{
		while (++x[1] < map_size[1])
		{
			if ((x[0] == 0 || x[1] == 0) && sq.size == 0)
				if (ca[x[0]][x[1]] == 1)
					sq = ft_init_size_to_one(x);
			if (x[0] > 0 && x[1] > 0 & ca[x[0]][x[1]] > 0)
			{
				ca[x[0]][x[1]] = 1 + ft_min(ca[x[0]][x[1] - 1],
				ca[x[0] - 1][x[1]], ca[x[0] - 1][x[1] - 1]);
				if (ca[x[0]][x[1]] > sq.size)
					sq = ft_find_largest_square(ca, x);
			}
		}
		x[1] = -1;
	}
	return (sq);
}
