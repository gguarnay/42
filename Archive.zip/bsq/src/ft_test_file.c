/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_test_file.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/14 22:43:26 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/14 22:43:37 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

int			ft_test_first_char(char *buf)
{
	if (buf[0] < '0' || buf[0] > '9')
		return (10);
	return (0);
}

int			ft_test_allowed_chars(char *buf)
{
	int		i;
	int		j;
	char	c[4];

	i = 0;
	j = 0;
	while ((buf[i] >= '0' && buf[i] <= '9') && buf[i])
		i++;
	while (buf[i] != '\n')
		c[j++] = buf[i++];
	if (j != 3)
		return (1);
	c[2] = '\n';
	if (buf[++i] == '\0' || atoi(buf) == 0)
		return (1);
	while (buf[i++])
	{
		if (buf[i] != c[0] && buf[i] != c[1] && buf[i] != c[2]
		&& buf[i] != '\0')
			return (1);
	}
	return (0);
}

int			ft_test_cols(char *buf)
{
	int		i;
	int		rolen;
	int		nl_flag;

	i = 0;
	rolen = 0;
	nl_flag = 0;
	while (buf[i] != '\n' && buf[i] != '\0')
		i++;
	while (buf[++i] != '\n' && buf[i] != '\0')
		rolen++;
	i++;
	nl_flag = rolen;
	while (buf[i] != '\0')
	{
		nl_flag--;
		if (buf[i] == '\n')
		{
			if (nl_flag != -1)
				return (30);
			nl_flag = rolen;
		}
		i++;
	}
	return (0);
}

int			ft_test_rows(char *buf)
{
	int		i;
	int		rn;
	char	line_num[10];
	int		lcount;

	i = -1;
	rn = 0;
	lcount = 0;
	while (++i < 10)
		line_num[i] = buf[i];
	rn = ft_atoi(line_num);
	i = 0;
	while (buf[i] != '\0')
	{
		if (buf[i] == '\n')
			lcount++;
		i++;
	}
	if (lcount - 1 != rn)
		return (100);
	return (0);
}
