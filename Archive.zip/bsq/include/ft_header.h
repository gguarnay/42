/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_header.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/12 14:06:38 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/12 14:06:41 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_HEADER_H
# define FT_HEADER_H
# include <stdlib.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>

typedef struct	s_square_br
{
	int row;
	int col;
	int size;
}				t_square_br;

typedef struct	s_filedesc
{
	int		map_size[2];
	int		is_valid;
	int		b_size;
	char	c[3];
	int		si;
}				t_filedesc;

typedef struct	s_tabs
{
	char	**re;
	int		**ca;
}				t_tabs;

typedef struct	s_fdret
{
	int fd;
	int ret;
}				t_fdret;

int				ft_atoi(char *str);
int				is_whitesp(char *str, int i);
int				is_digit(char *str, int i);
int				ft_strlen(char *s);
void			ft_putstr(char *s);
t_square_br		ft_solve_bsq(int **cache, int *map_size);
int				ft_min(int a, int b, int c);
void			ft_display(char **re, t_square_br res, int *map_size, char c);
void			ft_init_ix(int *ix);
t_square_br		ft_init_size_to_one(int *ix);
t_square_br		ft_find_largest_square(int **ca, int *ix);
int				ft_controller(char *filename);
int				ft_ideal_buffer_size(char *filename);
int				ft_ideal_buffer_size_stdin(void);
void			ft_fill_allowed_chars(char *buf, t_filedesc *f_desc);
void			ft_extract_file_desc(t_filedesc *f_desc, int fd, int buf_size);
void			ft_import_data(int *f, t_filedesc *f_d, char *buf, t_tabs *t);
void			ft_import_data_stdin(int r, t_filedesc *f, char *b, t_tabs *t);
int				ft_check_map_validity(char *filename);
int				ft_check_map_validity_stdin(void);
t_filedesc		ft_file_preprocessing(char *filename);
t_filedesc		ft_stdin_preprocessing(void);
int				ft_ctrl_preprocessing(char *file, t_filedesc *f_desc, int *fd);
int				ft_controller(char *filename);
int				ft_openfile_error(int fd);
int				ft_closefile_error(int fd);
void			ft_init_x_tabs(int *ix);
t_tabs			*ft_init_tabs(t_filedesc f_desc);
int				ft_init_buf_ret(char *buf, int fd, int b_size);
int				ft_test_first_char(char *buf);
int				ft_test_allowed_chars(char *buf);
int				ft_test_cols(char *buf);
int				ft_test_rows(char *buf);

#endif
