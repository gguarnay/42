/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solvesudoku.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 14:15:52 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/04 17:11:14 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_header.h"

int		ft_avail_pos_count(int **array)
{
	int i;
	int j;
	int count_zeros;

	i = -1;
	j = -1;
	count_zeros = 0;
	while (++i < 9)
	{
		while (++j < 9)
		{
			if (array[i][j] == 0)
				count_zeros++;
		}
		j = -1;
	}
	return (count_zeros);
}

void	ft_solvesudoku(int **array, t_pos *fpositions)
{
	t_pos *positions;

	positions = (t_pos *)malloc(sizeof(t_pos) * ft_avail_pos_count(array));
	fpositions++;
	ft_displaysudoku(array);
}
