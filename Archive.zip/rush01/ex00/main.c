/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 13:21:43 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/04 17:09:34 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_header.h"

void	ft_putstr(char *s)
{
	while (*s)
	{
		ft_putchar(*s);
		s++;
	}
}

int		ft_fposition_count(char **argv)
{
	int i;
	int j;
	int count;

	i = -1;
	j = -1;
	count = 0;
	while (++i < 9)
	{
		while (++j < 9)
		{
			if (argv[i + 1][j] == '.')
				count++;
		}
		j = -1;
	}
	return (count);
}

t_pos	*ft_fposition_creator(char **argv)
{
	int		count;
	t_pos	*fpositions;
	int		i;
	int		j;

	count = ft_fposition_count(argv);
	fpositions = (t_pos *)malloc(sizeof(t_pos) * count);
	i = -1;
	j = -1;
	count = 0;
	while (++i < 9)
	{
		while (++j < 9)
		{
			if (argv[i + 1][j] != '.')
			{
				fpositions[count].row = i;
				fpositions[count].col = j;
				fpositions[count].value = argv[i + 1][j];
				count++;
			}
		}
		j = -1;
	}
	return (fpositions);
}

int		ft_is_ko_arg_num(int argc)
{
	if (argc != 10)
	{
		ft_putstr("Error\n");
		return (1);
	}
	return (0);
}

int		main(int argc, char **argv)
{
	int		i;
	int		j;
	int		**array;
	t_pos	*fpositions;

	if (ft_is_ko_arg_num(argc) == 1)
		return (0);
	array = (int **)malloc(sizeof(int *) * 9);
	i = -1;
	j = -1;
	fpositions = ft_fposition_creator(argv);
	while (++i < 9)
	{
		array[i] = (int *)malloc(sizeof(int) * 9);
		while (++j < 9)
		{
			if (argv[i + 1][j] != '.')
				array[i][j] = argv[i + 1][j] - '0';
			else
				array[i][j] = 0;
		}
		j = -1;
	}
	ft_solvesudoku(array, fpositions);
	return (0);
}
