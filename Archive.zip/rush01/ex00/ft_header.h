/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_header.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 16:40:41 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/04 17:05:02 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_HEADER_H
# define FT_HEADER_H

typedef struct	s_position
{
	int row;
	int col;
	int value;
}				t_pos;

void			ft_displaysudoku(int **array);
void			ft_putchar(char c);
void			ft_solvesudoku(int **array, t_pos *fpositions);

#endif
