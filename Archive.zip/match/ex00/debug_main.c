/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   match.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 00:15:14 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/04 01:46:44 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	test_empty_string(char *s1, char *s2)
{
	if ((*s1 == '\0' && *s2 != '\0')
			|| (*s1 != '\0' && *s2 == '\0'))
		return (0);
	return (1);
}

int	ft_strlen(char *s)
{
	int len;

	len = 0;
	if (*s)
		len++;
	return (len);
}

int	match(char *s1, char *s2)
{
	int i;
	int j;

	i = -1;
	j = 0;
	while (s2[++i])
	{
		if (s2[i] != '*')
			if (s1[j] != s2[i])
				return (0);
		if (s2[i] == '*')
		{
			while ((s2[i] == '*') && (s2[i + 1] != '\0'))
				i++;
			if (s2[i + 1] == '\0')
				return (1);
			j--;
			while (s1[++j] != s2[i])
				if (s1[j] == '\0')
					return (0);
		}
		j++;
	}
	if ((i > 1 && s2[i - 2] == '*' && s2[i-1] != '*') && (s2[i-1] == s1[ft_strlen(s1) - 1])) // case s2 finish with a character
		return (1);
	return (test_empty_string(s1, s2));
}

int	main(void)
{
	printf("%s\n%s\n\t%d\t (1 is identical, 0 is different)\n", "asdf", "a", match("asdf", "a"));
	printf("%s\n%s\n\t%d\t (1 is identical, 0 is different)\n", "asdff", "asdf", match("asdff", "asdf"));
	printf("%s\n%s\n\t%d\t (1 is identical, 0 is different)\n", "attatat", "a*t", match("attatat", "a*t"));
	printf("%s\n%s\n\t%d\t (1 is identical, 0 is different)\n", "f", "*a", match("f", "*a"));
	printf("%s\n%s\n\t%d\t (1 is identical, 0 is different)\n", "verg", "***", match("verg", "***"));
	return (0);
}
