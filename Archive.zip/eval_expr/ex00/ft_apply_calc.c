/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_apply_calc.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/10 17:15:30 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/10 17:15:34 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

char	*left(char *s, int i)
{
	int		count;
	int		k;
	int		j;
	char	*res;

	count = 2;
	k = i;
	while (count > 0 && k >= 0)
	{
		if (*(s + k) == ' ' || k == 0)
			count--;
		if (!(*(s + k) == ' ' && count == 0))
			k--;
	}
	res = (char *)malloc(sizeof(char) * (i - k));
	j = 0;
	while (j < i - k - 2)
	{
		res[j] = *(s + k + 1 + j);
		j++;
	}
	res[j] = '\0';
	return (res);
}

char	*right(char *s, int i)
{
	int		count;
	int		k;
	int		j;
	char	*res;

	count = 2;
	k = i;
	while (count > 0 && *(s + k) != '\0')
	{
		if (*(s + k) == ' ')
			count--;
		k++;
	}
	if (*(s + k) == '\0')
		k++;
	res = (char *)malloc(sizeof(char) * (k - i));
	j = 0;
	while (j < k - i - 3)
	{
		res[j] = *(s + i + 2 + j);
		j++;
	}
	res[j] = '\0';
	return (res);
}

int		ft_calculate(int a, int b, char op)
{
	if (op == '*')
		return (ft_mul(a, b));
	if (op == '/')
		return (ft_div(a, b));
	if (op == '+')
		return (ft_add(a, b));
	if (op == '-')
		return (ft_sub(a, b));
	if (op == '%')
		return (ft_mod(a, b));
	return (0);
}

int		ft_hasb(char *s)
{
	while (*s)
	{
		if (*s == '(')
			return (1);
		s++;
	}
	return (0);
}

int		ft_ix_restart(char *s, int open, int close)
{
	char	*str;
	int		i;
	int		strlen;

	i = -1;
	str = (char *)malloc(sizeof(char) * (close - open));
	while (++i < close - open - 1)
		str[i] = *(s + open + 1 + i);
	str[i] = '\0';
	strlen = ft_strlen(ft_itoa(ft_str_no_bracket(str)));
	return (open + strlen - 1);
}
