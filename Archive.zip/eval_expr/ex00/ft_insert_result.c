/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_insert_result.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/11 15:47:19 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/11 15:47:39 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

char	*ft_insert_result(char *s, int *open_clo_res, int strlen)
{
	int		i;
	int		j;
	char	*s2;
	int		size;

	size = ft_strlen(s) - (open_clo_res[1] - open_clo_res[0] + 1) + strlen;
	s2 = (char *)malloc(size);
	i = -1;
	while (++i < open_clo_res[0])
		s2[i] = s[i];
	j = 0;
	while (j < strlen)
	{
		s2[i] = *(ft_itoa(open_clo_res[2]) + j);
		i++;
		j++;
	}
	j = 0;
	while (s[open_clo_res[1] + 1 + j])
	{
		s2[i] = s[open_clo_res[1] + 1 + j];
		i++;
		j++;
	}
	return (s2);
}
