/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_eval_expr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/10 15:46:38 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/10 15:46:43 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

char	*ft_fill_eval(char *s, char *res, int start, int beg)
{
	int		i;
	int		j;
	char	*temp;

	i = -1;
	temp = (char *)malloc(sizeof(char) * (ft_strlen(s) + ft_strlen(res) + 1));
	while (++i < beg)
		temp[i] = s[i];
	j = i;
	while (res[i - j])
	{
		temp[i] = res[i - j];
		i++;
	}
	if ((s[start]))
	{
		j = i;
		while (s[i - j + start])
		{
			temp[i] = s[i - j + start];
			i++;
		}
	}
	temp[i] = '\0';
	return (temp);
}

char	*ft_str_apply_op(char *s, char *sa, char *sb, int i_)
{
	int		ab[2];
	int		res;
	int		i;
	char	*s2;
	char	*s3;

	i = 0;
	s2 = (char *)malloc(sizeof(char) * (ft_strlen(s) + 1));
	while (s[i])
	{
		s2[i] = s[i];
		i++;
	}
	ab[0] = atoi(sa);
	ab[1] = atoi(sb);
	res = ft_calculate(ab[0], ab[1], s[i_]);
	s3 = (char *)malloc(ft_strlen(s2) - ft_strlen(sa) - ft_strlen(sb) - 3
	+ ft_strlen(ft_itoa(res)));
	s3 = ft_fill_eval(s2, ft_itoa(res), i_ + ft_strlen(sb) + 2,
	i_ - 1 - ft_strlen(sa));
	return (s3);
}

int		ft_str_no_bracket(char *s)
{
	int		i;
	int		res;

	i = 0;
	while (s[i])
	{
		if (*(s + i) == '*' || *(s + i) == '/' || *(s + i) == '%')
		{
			s = ft_str_apply_op(s, left(s, i), right(s, i), i);
			i = 0;
		}
		i++;
	}
	i = 0;
	while (s[i])
	{
		if (i > 0 && (*(s + i) == '+' || *(s + i) == '-'))
		{
			s = ft_str_apply_op(s, left(s, i), right(s, i), i);
			i = 0;
		}
		i++;
	}
	res = atoi(s);
	return (res);
}

char	*ft_str_in_bracket(char *s, int open, int close)
{
	char	*str;
	char	*s2;
	int		open_clo_res[3];
	int		i;
	int		strlen;

	i = -1;
	open_clo_res[0] = open;
	open_clo_res[1] = close;
	str = (char *)malloc(sizeof(char) * (open_clo_res[1] - open_clo_res[0]));
	while (++i < open_clo_res[1] - open_clo_res[0] - 1)
		str[i] = *(s + open_clo_res[0] + 1 + i);
	str[i] = '\0';
	strlen = ft_strlen(ft_itoa(ft_str_no_bracket(str)));
	open_clo_res[2] = ft_str_no_bracket(str);
	s2 = ft_insert_result(s, open_clo_res, strlen);
	return (s2);
}

int		eval_expr(char *str)
{
	int		i;
	int		close_b;
	int		open_b;
	int		open_b2;
	char	*s;

	i = 0;
	while (*(str + i))
	{
		if (*(str + i) == ')')
		{
			close_b = i;
			while (*(str + i) != '(')
				i--;
			open_b = i;
			open_b2 = ft_ix_restart(str, open_b, close_b);
			s = ft_str_in_bracket(str, open_b, close_b);
			str = s;
			i = open_b2;
		}
		i++;
	}
	return (ft_hasb(str) == 1 ? ft_str_no_bracket(s) : ft_str_no_bracket(str));
}
