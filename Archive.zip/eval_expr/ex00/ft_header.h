/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_header.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/10 13:19:50 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/10 13:19:50 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_HEADER_H
# define FT_HEADER_H
# include <stdlib.h>
# include <unistd.h>

int		is_whitesp(char *str, int i);
int		is_digit(char *str, int i);
int		ft_atoi(char *str);
int		ft_lenint(int n);
char	*ft_itoa(int n);
void	ft_putchar(char c);
void	ft_putstr(char *s);
int		ft_strlen(char *s);
int		ft_add(int a, int b);
int		ft_sub(int a, int b);
int		ft_mod(int a, int b);
int		ft_mul(int a, int b);
int		ft_div(int a, int b);
int		ft_calculate(int a, int b, char op);
int		eval_expr(char *str);
char	*ft_str_rep(char *s, int open, int close);
int		ft_ix_restart(char *s, int open, int close);
int		ft_str_no_bracket(char *s);
char	*ft_insert_result(char *s, int *open_clo_res, int strlen);
char	*ft_str_in_bracket(char *s, int open, int close);
char	*ft_str_apply_op(char *s, char *sa, char *sb, int i_);
char	*ft_fill_eval(char *s, char *res, int start, int beg);
int		ft_hasb(char *s);
char	*left(char *s, int i);
char	*right(char *s, int i);
void	ft_putnbr(int n);

#endif
