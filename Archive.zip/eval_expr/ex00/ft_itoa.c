/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/10 17:00:23 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/10 17:13:18 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

int		ft_lenint(int n)
{
	int i;

	i = 0;
	if (n <= 0)
		i = 1;
	while (n != 0)
	{
		n = n / 10;
		i++;
	}
	return (i);
}

char	*ft_itoa(int n)
{
	int				sign;
	int				len;
	unsigned int	nb;
	char			*sa;

	sign = 0;
	if (n < 0)
		sign = 1;
	len = ft_lenint(n);
	if (n < 0)
		nb = -n;
	else
		nb = n;
	sa = NULL;
	if (!(sa = (char *)malloc(sizeof(*sa) * (len + 1))))
		return (NULL);
	sa[len] = '\0';
	while (--len >= 0)
	{
		sa[len] = nb % 10 + '0';
		nb = nb / 10;
	}
	if (sign == 1)
		sa[0] = '-';
	return (sa);
}
