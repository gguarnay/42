/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sastantua.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/28 15:38:24 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/28 21:03:17 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

void	sastantua(int size)
{
	int row;
	int col;
	int size_x;
	int size_y;
	int index_mod;
	int offset;

	row = 0;
	col = 0;
	index_mod = 3;
	offset = 0;
	if (size <= 0)
		return;
	size_y = 2 * size + (size * (size + 1)) / 2;
	size_x = 7 + 2 * (size - 1) * (size / 2 + 1) + 2 * (2 * (size - 1) + size * (size + 1) / 2 - 1);
	while (++row <= size_y)
	{
		while (++col <= size_x)
		{
			if (col == size_y - row + 1)
				ft_putchar('/');
			else if ((col > size_y - row + 1) && (col < size_x - size_y + row))
				ft_putchar('*');
			else if (col == size_x - size_y + row)
				ft_putchar('\\');
			else if (col == size_y - row + 1)
				ft_putchar('/');
			else
				ft_putchar(' ');
		}
		ft_putchar('\n');
		col = 0;
	}
}
