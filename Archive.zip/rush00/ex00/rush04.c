/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/28 14:50:23 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/28 15:28:09 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_putchar(char c);

int	rush(int x, int y)
{
	int rw;
	int cl;

	rw = 0;
	cl = 0;
	if ((x <= 0) || (y <= 0) || (x > 2147483647) || (y > 2147483647))
		return (0);
	while (++rw <= y)
	{
		while (++cl <= x)
		{
			if ((rw == 1 && cl == 1) || (rw == y && cl == x && y > 1 && x > 1))
				ft_putchar('A');
			else if (((rw == 1) && (cl == x)) || ((rw == y) && (cl == 1)))
				ft_putchar('C');
			else if (((cl > 1 && cl < x) && (rw == 1 || rw == y))
				|| ((rw > 1 && rw < y) && (cl == 1 || cl == x)))
				ft_putchar('B');
			else
				ft_putchar(' ');
		}
		ft_putchar('\n');
		cl = 0;
	}
	return (0);
}
