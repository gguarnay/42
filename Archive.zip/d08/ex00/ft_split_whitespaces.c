/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/02 12:38:09 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/03 19:19:27 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_wordcount(char *s)
{
	int		flag;
	int		wc;

	flag = 0;
	wc = 0;
	while (*s)
	{
		if (*s == ' ' || *s == '\t' || *s == '\n')
			flag = 0;
		else if (flag == 0)
		{
			flag = 1;
			wc++;
		}
		s++;
	}
	return (wc);
}

int		ft_strlen(char *str)
{
	int		len;

	len = 0;
	while (*str)
	{
		len++;
		str++;
	}
	return (len);
}

char	*ft_find_kth_word(char *s, int k)
{
	int		flag;
	int		wc;
	char	*scpy;
	int		i;

	flag = 0;
	wc = 0;
	i = -1;
	scpy = (char *)malloc((1 + ft_strlen(s)) * sizeof(char));
	while (s[++i] != '\0')
		scpy[i] = s[i];
	while (*scpy)
	{
		if (*scpy == ' ' || *scpy == '\t' || *scpy == '\n')
			flag = 0;
		else if (flag == 0)
		{
			flag = 1;
			wc++;
		}
		if (wc == k)
			return (scpy);
		scpy++;
	}
	return ("");
}

char	*ft_remove_space(char *s)
{
	int		i;

	i = 0;
	while (s[i] != '\0')
	{
		if (s[i] == ' ' || s[i] == '\t' || s[i] == '\n')
		{
			s[i] = '\0';
		}
		i++;
	}
	return (s);
}

char	**ft_split_whitespaces(char *str)
{
	char	**arr;
	char	*word;
	int		wc;
	int		i;

	wc = ft_wordcount(str);
	arr = (char **)malloc(sizeof(char *) * (wc + 1));
	i = 0;
	while (i < wc)
	{
		word = (char *)malloc(sizeof(char) * (ft_strlen(str) + 1));
		word = ft_find_kth_word(str, i + 1);
		word = ft_remove_space(word);
		arr[i] = word;
		i++;
	}
	arr[i] = 0;
	return (arr);
}
