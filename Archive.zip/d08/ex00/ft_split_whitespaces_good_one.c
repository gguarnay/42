/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/02 12:38:09 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/06 18:48:07 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tkatolik <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/03 20:30:05 by tkatolik          #+#    #+#             */
/*   Updated: 2018/11/03 23:30:14 by tkatolik         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_wordcount(char *s)
{
	int		flag;
	int		wc;

	flag = 0;
	wc = 0;
	while (*s)
	{
		if (*s == ' ' || *s == '\t' || *s == '\n')
			flag = 0;
		else if (flag == 0)
		{
			flag = 1;
			wc++;
		}
		s++;
	}
	return (wc);
}

int		ft_strlen(char *str)
{
	int		len;

	len = 0;
	while (*str)
	{
		len++;
		str++;
	}
	return (len);
}

char	*ft_find_kth_word(char *s, int k)
{
	int		flag;
	int		wc;
	char	*scpy;
	int		i;

	flag = 0;
	wc = 0;
	i = -1;
	scpy = (char *)malloc((1 + ft_strlen(s)) * sizeof(char));
	while (s[++i] != '\0')
		scpy[i] = s[i];
	while (*scpy != '\0')
	{
		if (*scpy == ' ' || *scpy == '\t' || *scpy == '\n')
			flag = 0;
		else if (flag == 0)
		{
			flag = 1;
			wc++;
		}
		if (wc == k)
			return (scpy);
		scpy++;
	}
	return ("");
}

char	*ft_remove_space(char *s, int nb)
{
	int		i;
	char	*tab;

	tab = (char *)malloc(sizeof(char) * nb + 1);
	i = 0;
	while (s[i] != '\0')
	{
		tab[i] = s[i];
		if (s[i] == ' ' || s[i] == '\t' || s[i] == '\n')
		{
			tab[i] = '\0';
			break;
		}
		i++;
	}
	return (tab);
}

char	**ft_split_whitespaces(char *str)
{
	char	**arr;
	char	*word;
	int		wc;
	int		i;

	wc = ft_wordcount(str);
	arr = (char **)malloc(sizeof(char *) * (wc + 1));
	i = 0;
	if (wc == 0)
	{
		*arr = (char *)malloc(sizeof(char) * ft_strlen(str) + 1);
	  	*arr = 0;
	    return (arr);
	}
	while (i < wc)
	{
		word = (char *)malloc(sizeof(char) * (ft_strlen(str) + 2));
		word = ft_find_kth_word(str, i + 1);
		word = ft_remove_space(word, ft_strlen(word));
		arr[i] = word;
		i++;
	}
	arr[i] = 0;
	return (arr);
}
