#include <stdio.h>
#include <stdlib.h>

char	**ft_split_whitespaces(char *str);
int		ft_wordcount(char *str);

int		main(void)
{
	//char	*str = "hicd efg\thi\nklmno pin\n why not\n";
	char	*str = "hi sir how are you i am good thanks";
	char	**arr;
	int		i=0;
	char	**res;

	arr = ft_split_whitespaces(str);

	for (res = ft_split_whitespaces("asdf qwerty zxcv"); *res != 0; res++)
		printf("'%s',", *res);
		printf("\n");
	for (res = ft_split_whitespaces("s1   s2 \t\n\t\ns3"); *res != 0; res++)
		printf("'%s',", *res);
		printf("\n");
	
/*	while (arr[i] != NULL)
	{
		printf("%s\n", arr[i]);
		i++;
	}*/
	return (0);
}
