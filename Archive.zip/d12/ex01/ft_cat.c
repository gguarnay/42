/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cat.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/08 18:21:28 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/08 22:08:43 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "ft_file.h"
#define BUFFER_SIZE 40

void	ft_putstr(char *s)
{
	while (*s)
	{
		write(1, s, 1);
		s++;
	}
}

void	ft_cat_empty(void)
{
	int		ret;
	int		fd;
	char	buf[BUFFER_SIZE + 1];

	while (1 == 1)
	{
		fd = open(STDIN_FILENO, O_RDONLY);
		ret = read(STDIN_FILENO, buf, BUFFER_SIZE);
		if (ret > 0)
		{
			buf[ret] = '\0';
			ft_putstr(buf);
		}
		close(fd);
	}
}

int		main(int argc, char **argv)
{
	int		fd;
	int		ret;
	char	buf[BUFFER_SIZE + 1];

	if (argc >= 2)
		return (1);
	if (argc == 1)
		ft_cat_empty();
	fd = open(argv[1], O_RDONLY);
	if (fd == -1)
	{
		ft_putstr("open() failed\n");
		return (1);
	}
	ret = read(fd, buf, BUFFER_SIZE);
	while (ret)
	{
		buf[ret] = '\0';
		ft_putstr(buf);
		ret = read(fd, buf, BUFFER_SIZE);
	}
	return (0);
}
