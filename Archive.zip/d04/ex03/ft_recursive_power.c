/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/26 15:09:31 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/27 22:01:25 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	int prev;

	if (power < 0)
		return (0);
	if (power > 31 && (nb != 0 || nb != 1))
		return (-1);
	if (power == 0)
		return (1);
	prev = ft_recursive_power(nb, power - 1);
	if (prev > 2147483647 / nb)
		return (0);
	else
	{
		return (nb * prev);
	}
}
