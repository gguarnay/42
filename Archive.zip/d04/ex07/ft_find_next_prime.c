/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/27 22:23:34 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/27 22:37:23 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_find_next_prime(int nb)
{
	int i;
	int res;

	i = 2;
	res = 1;
	if ((nb <= 1))
		return (2);
	while (i * i <= nb)
	{
		if (nb % i == 0)
		{
			res = 0;
			return (ft_find_next_prime(nb + 1));
		}
		i++;
	}
	return (nb);
}
