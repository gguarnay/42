#!/bin/sh

gcc -Wall -Wextra -Werror -c ft_*.c;
ar rc libft.a ft_*.o;
