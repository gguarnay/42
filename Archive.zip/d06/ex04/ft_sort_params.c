/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/30 13:00:01 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/30 16:34:41 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

int		local_ft_strcmp(char *s1, char *s2)
{
	int i;

	i = 0;
	while (s1[i] != '\0')
	{
		if (s1[i] == s2[i])
			i++;
		else
			return (*(s1 + i) - *(s2 + i));
	}
	return (s1[i] - s2[i]);
}

void	local_ft_swap(int *a, int *b)
{
	int temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

void	ft_fill_int_array(int *tab, int nb)
{
	int i;

	i = 0;
	while (++i <= nb)
		tab[i - 1] = i;
}

void	local_ft_putstr(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar(str[i]);
		i++;
	}
}

int		main(int argc, char **argv)
{
	int i;
	int j;
	int ix[argc - 1];

	i = 0;
	ft_fill_int_array(ix, argc - 1);
	while (++i <= argc - 1)
	{
		j = i;
		while (++j <= argc - 1)
		{
			if (local_ft_strcmp(argv[ix[i - 1]], argv[ix[j - 1]]) > 0)
				local_ft_swap(ix + i - 1, ix + j - 1);
		}
	}
	i = -1;
	while (++i < argc - 1)
	{
		local_ft_putstr(argv[ix[i]]);
		ft_putchar('\n');
	}
	return (0);
}
