/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_clear.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/06 22:55:24 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/07 18:21:47 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>

void	ft_list_clear(t_list **begin_list)
{
	t_list *temp;

	if (!(*begin_list))
		return ;
	while (*begin_list)
	{
		temp = (*begin_list);
		*begin_list = (*begin_list)->next;
		free(temp);
	}
}
