/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_size.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/06 17:13:27 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/07 23:17:42 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

int	ft_list_size(t_list *begin_list)
{
	int		count;
	t_list	*temp;

	count = 0;
	if (!begin_list)
		return (0);
	temp = begin_list;
	while (temp->next)
	{
		count++;
		temp = temp->next;
	}
	return (count + 1);
}
