/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_params.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/06 17:34:29 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/07 18:13:43 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>

t_list	*ft_list_push_params(int ac, char **av)
{
	t_list	*list;
	t_list	*prev;
	int		i;

	i = 0;
	list = NULL;
	while (i < ac)
	{
		prev = ft_create_elem(av[i]);
		if (list)
			prev->next = list;
		list = prev;
		i++;
	}
	return (list);
}
