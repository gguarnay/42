/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_reverse_fun.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/07 21:37:31 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/07 22:07:56 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>

t_list	*ft_list_at(t_list *begin_list, unsigned int nbr)
{
	unsigned int	i;
	t_list			*list;

	list = begin_list;
	i = 0;
	if (!(begin_list))
		return (NULL);
	while (list)
	{
		if (i == nbr)
			return (list);
		list = list->next;
		i++;
	}
	return (NULL);
}

int		ft_list_size(t_list *begin_list)
{
	int count;

	count = 0;
	if (!begin_list)
		return (0);
	while (begin_list[count].next)
		count++;
	return (count + 1);
}

void	ft_list_reverse_fun(t_list *begin_list)
{
	int		i;
	int		len;
	t_list	*current;
	void	*temp;

	i = 0;
	len = ft_list_size(begin_list);
	if (!begin_list)
		return ;
	current = begin_list;
	while (i <= (len - 1) / 2)
	{
		temp = current->data;
		current->data = ft_list_at(begin_list, len - 1 - i)->data;
		ft_list_at(begin_list, len - 1 - i)->data = temp;
		i++;
		current = current->next;
	}
}
