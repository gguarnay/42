/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_remove_if.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/07 16:23:28 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/07 18:17:56 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>

void	ft_list_remove_if(t_list **begin_list, void *data_ref, int (*cmp)())
{
	t_list *current;
	t_list *prev;

	if (!(*begin_list))
		return ;
	prev = *begin_list;
	current = prev->next;
	while (prev->next)
	{
		current = prev->next;
		if (cmp(current->data, data_ref) == 0)
		{
			prev->next = current->next;
			free(current);
		}
		else
			prev = prev->next;
	}
	if (cmp((*begin_list)->data, data_ref) == 0)
	{
		prev = (*begin_list);
		(*begin_list) = (*begin_list)->next;
		free(prev);
	}
	return ;
}
