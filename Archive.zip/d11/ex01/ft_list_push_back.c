/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_back.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/06 12:15:52 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/06 16:00:43 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void	ft_list_push_back(t_list **begin_list, void *data)
{
	t_list	*temp;
	t_list	*current;

	temp = ft_create_elem(data);
	current = *begin_list;
	if (!(*begin_list))
		*begin_list = temp;
	else
	{
		while (current->next)
			current = current->next;
		current->next = temp;
	}
}
