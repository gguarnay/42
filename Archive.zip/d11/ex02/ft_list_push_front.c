/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_front.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/06 16:03:09 by gguarnay          #+#    #+#             */
/*   Updated: 2018/11/06 17:09:57 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void	ft_list_push_front(t_list **begin_list, void *data)
{
	t_list *prev_list_element;

	prev_list_element = ft_create_elem(data);
	if (!*begin_list)
		*begin_list = prev_list_element;
	else
	{
		prev_list_element->next = *begin_list;
		*begin_list = prev_list_element;
	}
}
