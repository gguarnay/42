/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/29 22:27:38 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/30 20:42:14 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int				local_ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int i;
	unsigned int j;
	unsigned int dest_len;
	unsigned int src_len;

	i = 0;
	dest_len = (unsigned int)local_ft_strlen(dest);
	src_len = (unsigned int)local_ft_strlen(src);
	if (size == 0)
		return (src_len);
	if (dest_len >= size - 1)
		return (src_len + dest_len - 1);
	j = dest_len;
	while (src[i] != '\0' && j < size - 1)
	{
		dest[j] = src[i];
		j++;
		i++;
	}
	dest[j] = '\0';
	return (dest_len + src_len);
}
