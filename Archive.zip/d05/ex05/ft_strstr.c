/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/29 16:01:33 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/29 17:36:41 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		string_length(char *str)
{
	int i;

	i = 0;
	while (*(str + i) != '\0')
		i++;
	return (i);
}

char	*ft_strstr(char *str, char *tofind)
{
	int i;
	int j;
	int tofind_len;
	int found_char;

	i = 0;
	j = 0;
	tofind_len = string_length(tofind);
	found_char = 0;
	while (*(str + i) != '\0')
	{
		while (*(tofind + j) != '\0')
		{
			if (*(str + i + j) == *(tofind + j))
				found_char += 1;
			j++;
		}
		j = 0;
		if (found_char == tofind_len)
			return (str + i);
		found_char = 0;
		i++;
	}
	return (0);
}
