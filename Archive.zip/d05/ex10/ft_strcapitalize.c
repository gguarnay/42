/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/29 19:10:43 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/29 20:17:08 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		is_whitespa(char c)
{
	if ((c == ' ') || (c == '\t') || (c == '\r') ||
			(c == '\n') || (c == '\v') || (c == '\f'))
		return (1);
	return (0);
}

int		is_alphanumeric(char c)
{
	if ((c >= 'a' && c <= 'z')
		|| (c >= 'A' && c <= 'Z')
		|| (c >= '0' && c <= '9'))
		return (1);
	return (0);
}

int		is_lowercase(char c)
{
	if (c >= 'a' && c <= 'z')
		return (1);
	return (0);
}

int		is_uppercase(char c)
{
	if (c >= 'A' && c <= 'Z')
		return (1);
	return (0);
}

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 1;
	if (!str)
		return (0);
	if (is_lowercase(str[0]) == 1)
		str[0] -= 32;
	while (str[i] != '\0')
	{
		if (is_uppercase(str[i]) == 1)
			str[i] += 32;
		if (is_alphanumeric(str[i - 1]) == 0)
		{
			if (is_lowercase(str[i]) == 1)
				str[i] -= 32;
		}
		i++;
	}
	return (str);
}
