/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/30 22:39:30 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/30 23:39:43 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

void	ft_putstr(char *str)
{
		int i;

		i = 0;
		while (*(str + i) != '\0')
		{
			ft_putchar(*(str + i));
			i++;
		}
}

int		ft_strlen(char *str)
{
		int len;

		len = 0;
		while (*(str + len) != '\0')
		{
			len++;
		}
		return (len);
}

int		ft_iterative_power(int nb, int power)
{
	int i;
	int res;

	i = 0;
	res = 1;
	if (power < 0)
	{
		return (0);
	}
	while (i < power)
	{
		res = res * nb;
		i++;
	}
	return (res);
}

int		is_valid_base(char *base)
{
	int i;

	i = 0;
	while (base[i] != '\0')
	{
		if (!((base[i] >= 'a' && base[i] <= 'z')
			|| (base[i] >= 'A' && base[i] <= 'Z')
			|| (base[i] >= '0' && base[i] <= '9')))
			return (0);
		i++;
	}
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int i;
	int base_int;
	int base_power;
	int digits;
	int nbr_copy;
	char res[100];

	if (is_valid_base(base) == 0)
		return ;
	base_int = ft_strlen(base);
	i = -1;
	digits = 0;
	nbr_copy = nbr;
	while (nbr_copy / base_int != 0)
	{
		digits++;
		nbr_copy /= base_int;
	}
	while (++i < digits - 1)
	{
		base_power = ft_iterative_power(base_int, digits - 2 - i);
		res[i] = nbr / base_power + '0';
		nbr = nbr % base_power;
		base_power *= base_int;
	}
	ft_putstr(res);
}
