/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguarnay <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/29 20:21:38 by gguarnay          #+#    #+#             */
/*   Updated: 2018/10/29 20:39:44 by gguarnay         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_alphabetic(char c)
{
	if ((c >= 'a' && c <= 'z')
		|| (c >= 'A' && c <= 'Z'))
		return (1);
	return (0);
}

int	local_ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

int	ft_str_is_alpha(char *str)
{
	int i;
	int alphabetic_match;
	int len;

	i = 0;
	alphabetic_match = 0;
	len = local_ft_strlen(str);
	if (!str)
		return (1);
	while (str[i] != '\0')
	{
		if (is_alphabetic(str[i]) == 1)
			alphabetic_match += 1;
		i++;
	}
	if (alphabetic_match == len)
		return (1);
	return (0);
}
